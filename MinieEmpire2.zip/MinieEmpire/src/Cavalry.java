package MiniEmpire;

public class Cavalry extends Unit {
    public Cavalry() {
        super("Cavalry", 120, 15, 100);
    }
}
