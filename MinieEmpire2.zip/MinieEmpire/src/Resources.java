package MiniEmpire;

public class Resources {
    private int gold;
    private int wood;

    public Resources(int gold, int wood) {
        this.gold = gold;
        this.wood = wood;
    }

    public boolean canAfford(int goldCost, int woodCost) {
        return gold >= goldCost && wood >= woodCost;
    }

    public void spend(int goldCost, int woodCost) {
        gold -= goldCost;
        wood -= woodCost;
    }

    public void add(int goldAmount, int woodAmount) {
        gold += goldAmount;
        wood += woodAmount;
    }

    public void display() {
        System.out.println("Gold: " + gold + " | Wood: " + wood);
    }
}
