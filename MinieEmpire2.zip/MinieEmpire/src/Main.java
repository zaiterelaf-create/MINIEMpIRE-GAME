package MiniEmpire;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Welcome to Mini Empire ===");
        System.out.print("Name your kingdom: ");
        String kingdomName = scanner.nextLine().trim();

        if (kingdomName.isEmpty()) {
            kingdomName = "The Nameless Kingdom";
        }

        System.out.println("\nWelcome, ruler of " + kingdomName + "!");
        System.out.println("Your journey to build a mighty empire begins now...\n");

        Resources resources = new Resources(500, 300);
        Army playerArmy = new Army();

        List<TrainingBuilding> buildings = Arrays.asList(
                new TrainingBuilding("Barracks", 100, 50, Soldier.class, 5),  // Trains 5 Soldiers
                new TrainingBuilding("Archery Range", 150, 100, Archer.class, 3),  // Trains 3 Archers
                new TrainingBuilding("Stable", 200, 150, Cavalry.class, 2)  // Trains 2 Cavalry
        );

        int wave = 1;
        double difficultyMultiplier = 1.0;

        System.out.println("=== " + kingdomName + " ===");

        while (true) {
            if (playerArmy.isDefeated() && !canAffordAnyBuilding(resources, buildings)) {
                System.out.println("\n=== GAME OVER ===");
                System.out.println("The armies of " + kingdomName + " have been destroyed and no resources remain to rebuild.");
                break;
            }

            System.out.println("\n--- " + kingdomName + " Status ---");
            resources.display();
            playerArmy.displayGrouped();

            System.out.println("\n1. Train troops");
            System.out.println("2. Fight wave " + wave);
            System.out.println("3. Exit");
            System.out.print("Your choice: ");
            int choice = scanner.nextInt();

            if (choice == 1) {
                System.out.println("\nAvailable training buildings:");
                for (int i = 0; i < buildings.size(); i++) {
                    TrainingBuilding b = buildings.get(i);
                    System.out.println((i + 1) + ". " + b.name);
                    System.out.println("   Cost: " + b.goldCost + " Gold, " + b.woodCost + " Wood");
                    System.out.println("   Trains: " + b.getUnitsPerTraining() + " " + b.getUnitName());
                    System.out.println("   Individual stats → " + b.getUnitStats());
                    System.out.println(); // سطر فارغ للفصل
                }
                System.out.print("Choose building: ");
                int buildingChoice = scanner.nextInt() - 1;

                if (buildingChoice >= 0 && buildingChoice < buildings.size()) {
                    TrainingBuilding selected = buildings.get(buildingChoice);
                    if (resources.canAfford(selected.goldCost, selected.woodCost)) {
                        resources.spend(selected.goldCost, selected.woodCost);
                        playerArmy.addMultipleUnits(selected.unitType, selected.getUnitsPerTraining());
                        System.out.println("Successfully trained " + selected.unitsPerTraining + " " + selected.getUnitName() + " in " + kingdomName + "!");
                    } else {
                        System.out.println("Not enough resources!");
                    }
                } else {
                    System.out.println("Invalid choice!");
                }

            } else if (choice == 2) {
                Army enemyArmy = new MiniEmpire.Army();
                int enemyCount = wave * 2;

                for (int i = 0; i < enemyCount; i++) {
                    Soldier enemy = new Soldier();
                    enemy.setHealth((int) (100 * difficultyMultiplier));
                    enemy.attackPower = (int) (20 * difficultyMultiplier);
                    enemyArmy.addUnit(enemy);
                }

                double playerPower = playerArmy.calculateTotalPower();
                double enemyPower = enemyArmy.calculateTotalPower();

                // يعرض قبل المعركة
                System.out.println("\n=== Wave " + wave + " ===");
                System.out.println(enemyCount + " enemies marching on " + kingdomName + "!");
                System.out.println("Enemy army power: " + (int) enemyPower);
                System.out.println("Your army power: " + (int) playerPower);

                Random random = new Random();

                double playerEffectivePower = playerPower * (0.8 + random.nextDouble() * 0.4);
                double enemyEffectivePower = enemyPower * (0.8 + random.nextDouble() * 0.4);

                int killedEnemies;
                int rewardGold;
                int rewardWood;

                if (playerEffectivePower > enemyEffectivePower) {
                    // Victory: Kill all enemies, no army losses
                    killedEnemies = enemyCount;
                    rewardGold = killedEnemies * (int) (50 * difficultyMultiplier);
                    rewardWood = killedEnemies * (int) (30 * difficultyMultiplier);
                    resources.add(rewardGold, rewardWood);

                    System.out.println("Great victory for " + kingdomName + "! Your forces crushed the enemy.");
                    System.out.println("You killed all " + killedEnemies + " enemies.");
                    System.out.println("Gained " + rewardGold + " gold and " + rewardWood + " wood.");

                    wave++;

                    if (wave % 5 == 0) {
                        difficultyMultiplier *= 1.2;
                        System.out.println("Warning: Difficulty increased! Enemies are stronger, but rewards are greater.");
                    }
                } else {
                    // Defeat: Kill a portion of enemies, get partial rewards, but entire army dies
                    double ratio = playerEffectivePower / enemyEffectivePower;
                    killedEnemies = (int) (enemyCount * ratio);
                    killedEnemies = Math.max(0, Math.min(killedEnemies, enemyCount));  // Clamp between 0 and enemyCount
                    rewardGold = killedEnemies * (int) (50 * difficultyMultiplier);
                    rewardWood = killedEnemies * (int) (30 * difficultyMultiplier);
                    resources.add(rewardGold, rewardWood);

                    System.out.println("Defeat! The enemy overwhelmed your forces.");
                    System.out.println("You managed to kill " + killedEnemies + " enemies before your army was wiped out.");
                    System.out.println("Gained " + rewardGold + " gold and " + rewardWood + " wood from the fallen enemies.");

                    // Wipe out entire army
                    playerArmy.wipeArmy();
                    playerArmy.display(); // عشان يظهر إنو الجيش صفر

                    System.out.println("Your entire army has fallen...");
                }

            } else if (choice == 3) {
                System.out.println("Thank you for playing Mini Empire! Farewell, ruler of " + kingdomName + ".");
                break;
            } else {
                System.out.println("Invalid choice!");
            }
        }

        scanner.close();
    }

    private static boolean canAffordAnyBuilding(Resources resources, List<TrainingBuilding> buildings) {
        for (TrainingBuilding b : buildings) {
            if (resources.canAfford(b.goldCost, b.woodCost)) {
                return true;
            }
        }
        return false;
    }
}