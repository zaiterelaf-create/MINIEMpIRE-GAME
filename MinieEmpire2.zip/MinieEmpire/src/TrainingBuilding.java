package MiniEmpire;

public class TrainingBuilding {
    String name;
    int goldCost;
    int woodCost;
    Class<? extends Unit> unitType;

    // الإضافة الجديدة 1: عدد الجنود اللي يتدربوا مرة واحدة
    int unitsPerTraining;

    // الإضافة الجديدة 2: اسم الوحدات بالجمع (Soldiers, Archers, Cavalry) عشان العرض يبقى حلو
    // (اختياري بس مفيد جدًا)

    public TrainingBuilding(String name, int goldCost, int woodCost,
                            Class<? extends Unit> unitType, int unitsPerTraining) {
        this.name = name;
        this.goldCost = goldCost;
        this.woodCost = woodCost;
        this.unitType = unitType;
        this.unitsPerTraining = unitsPerTraining;  // مثلاً 5 للـ Barracks
    }

    public Unit produceUnit() {
        try {
            return unitType.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            return null;
        }
    }

    // دالة جديدة مهمة: ترجع عدد الجنود اللي بيتدربوا في المرة الواحدة
    public int getUnitsPerTraining() {
        return unitsPerTraining;
    }

    // دالة جديدة حلوة: ترجع الاسم بالجمع عشان الرسائل تبقى احترافية
    public String getUnitName() {
        if (unitType == Soldier.class) return "Soldiers";
        if (unitType == Archer.class) return "Archers";
        if (unitType == Cavalry.class) return "Cavalry";
        return "Troops";
    }
    // الدالة الجديدة: تعرض إحصائيات الجندي الواحد
    public String getUnitStats() {
        Unit sample = produceUnit();
        if (sample == null) return "Unknown stats";

        int health = sample.getHealth();
        int attack = sample.attackPower;

        // إضافة وصف بسيط حسب النوع (اختياري بس حلو)
        String role = "";
        if (unitType == Soldier.class) role = " (Balanced infantry)";
        else if (unitType == Archer.class) role = " (Ranged attacker)";
        else if (unitType == Cavalry.class) role = " (Fast and strong)";

        return String.format("Health: %d | Attack: %d%s", health, attack, role);
    }
}