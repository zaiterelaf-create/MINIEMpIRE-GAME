package MiniEmpire;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Army {
    private List<Unit> units = new ArrayList<>();

    public void addUnit(Unit unit) {
        units.add(unit);
    }

    public void removeDead() {
        units.removeIf(unit -> !unit.isAlive());
    }

    public boolean isDefeated() {
        return units.isEmpty() || units.stream().noneMatch(Unit::isAlive);
    }

    public Unit getRandomAliveUnit(Random random) {
        List<Unit> alive = units.stream().filter(Unit::isAlive).toList();
        if (alive.isEmpty()) return null;
        return alive.get(random.nextInt(alive.size()));
    }

    public void display() {
        System.out.println("--- Your Army ---");
        if (units.isEmpty()) {
            System.out.println("Empty");
        } else {
            for (Unit unit : units) {
                if (unit.isAlive()) {
                    unit.displayStatus();
                }
            }
        }
    }
    public int getAliveCount() {
        return (int) units.stream().filter(Unit::isAlive).count();
    }

    public double calculateTotalPower() {
        double total = 0;
        for (Unit unit : units) {
            if (unit.isAlive()) {
                double unitTypeMultiplier = 1.0;
                if (unit instanceof Archer) unitTypeMultiplier = 1.2;
                else if (unit instanceof Cavalry) unitTypeMultiplier = 1.5;

                total += (unit.attackPower + unit.getHealth()) * unitTypeMultiplier;
            }
        }
        return total;
    }

    // لازم تضيفي هذه الدالة كمان لو مش موجودة
    public List<Unit> getAliveUnits() {
        List<Unit> alive = new ArrayList<>();
        for (Unit unit : units) {
            if (unit.isAlive()) {
                alive.add(unit);
            }
        }
        return alive;
    }

    // 1. عرض الجيش مجمع حسب النوع (الأهم!)
    public void displayGrouped() {
        int soldiers = 0, archers = 0, cavalry = 0;

        for (Unit unit : units) {
            if (unit.isAlive()) {
                if (unit instanceof Soldier) soldiers++;
                else if (unit instanceof Archer) archers++;
                else if (unit instanceof Cavalry) cavalry++;
            }
        }

        System.out.print("Army: ");
        boolean hasTroops = false;

        if (soldiers > 0) {
            System.out.print(soldiers + " Soldiers");
            hasTroops = true;
        }
        if (archers > 0) {
            if (hasTroops) System.out.print(", ");
            System.out.print(archers + " Archers");
            hasTroops = true;
        }
        if (cavalry > 0) {
            if (hasTroops) System.out.print(", ");
            System.out.print(cavalry + " Cavalry");
            hasTroops = true;
        }

        if (!hasTroops) {
            System.out.print("No troops remaining");
        }
        System.out.println();
    }

    // 2. مسح الجيش كامل (لما تخسر المعركة)
    public void wipeArmy() {
        for (Unit unit : units) {
            unit.setHealth(0);  // نقتل كل الوحدات
        }
        removeDead();  // ننظف الليستة من الجثث (اختياري بس أفضل)
    }

    // 3. إضافة عدد من الوحدات مرة واحدة (بدل إضافة واحدة واحدة)
    public void addMultipleUnits(Class<? extends Unit> unitType, int count) {
        try {
            for (int i = 0; i < count; i++) {
                Unit newUnit = unitType.getDeclaredConstructor().newInstance();
                units.add(newUnit);
            }
        } catch (Exception e) {
            System.out.println("Error creating units!");
        }
    }
}
