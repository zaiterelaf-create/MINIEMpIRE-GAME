package MiniEmpire;

    public abstract class Unit {
        protected String name;
        protected int health;
        protected int attackPower;
        protected int goldCost;

        public Unit(String name, int health, int attackPower, int goldCost) {
            this.name = name;
            this.health = health;
            this.attackPower = attackPower;
            this.goldCost = goldCost;
        }

        public void attack(Unit target) {
            if (isAlive()) {
                int damage = attackPower;
                target.takeDamage(damage);
                System.out.println(name + " attacks " + target.name + " for " + damage + " damage!");
            }
        }

        public void takeDamage(int damage) {
            health -= damage;
            if (health < 0) health = 0;
        }

        public void displayStatus() {
            System.out.println(name + " - Health: " + health + " | Attack: " + attackPower + " | Cost: " + goldCost + " gold");
        }

        public boolean isAlive() {
            return health > 0;
        }

        public String getName() {
            return name;
        }

        public int getHealth() {
            return health;
        }

        public void setHealth(int health) {
            this.health = health;
        }
    }
