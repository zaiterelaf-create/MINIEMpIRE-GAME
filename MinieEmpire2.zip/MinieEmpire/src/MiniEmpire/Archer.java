package MiniEmpire;

public class Archer extends Unit {
    public Archer() {
        super("Archer", 80, 25, 75);
    }
}
