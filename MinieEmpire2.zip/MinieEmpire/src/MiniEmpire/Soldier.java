package MiniEmpire;

public class Soldier extends Unit {
    public Soldier() {
        super("Soldier", 100, 20, 50);
    }
}
